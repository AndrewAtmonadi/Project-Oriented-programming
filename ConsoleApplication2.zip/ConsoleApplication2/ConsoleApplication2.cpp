// Including necessary SFML libraries for graphics and window operations
#include <SFML/Graphics.hpp>

// Including standard libraries for various functionalities
#include <iostream>        // for input and output operations
#include <vector>          // for using dynamic arrays
#include <set>             // for using set containers
#include <map>             // for using map containers
#include <list>            // for using list containers
#include <string>          // for using string class
#include <cmath>           // for mathematical functions
#include <ctime>           // for time functions
#include <cstdlib>         // for random number generation

using namespace sf;        // Using the sf namespace to avoid prefixing with 'sf::'

// Constant definitions
const int WINDOW_WIDTH = 1200;      // Window width in pixels
const int WINDOW_HEIGHT = 800;      // Window height in pixels
const int MAX_INPUT_LENGTH = 50;    // Maximum length of user input
const int MAX_ASTEROIDS = 4;        // Maximum number of asteroids in the game
const float DEGREES_TO_RADIANS = 0.017453f; // Conversion factor for degrees to radians

// List of random words to be used for asteroids
std::vector<std::string> randomWords = {
    "hello", "world", "game", "spaceship", "asteroid",
    "programming", "code", "keyboard", "mouse", "screen", "skibidi", "adek",
    "typefighters", "typing", "andrew", "arav", "rohan", "atmonadi", "debisarun", "doerga",
    "aura", "cooked", "generation", "explosion", "object", "oriented", "aids", "freeshavacado"
};

// Animation class for handling sprite animations
class Animation {
public:
    float Frame, speed;
    Sprite sprite;
    std::vector<IntRect> frames;

    Animation() : Frame(0), speed(0) {}

    Animation(Texture& texture, int x, int y, int width, int height, int count, float Speed) {
        Frame = 0;
        speed = Speed;

        for (int i = 0; i < count; i++)
            frames.push_back(IntRect(x + i * width, y, width, height));

        sprite.setTexture(texture);
        sprite.setOrigin(width / 2, height / 2);
        sprite.setTextureRect(frames[0]);
    }

    void update() {
        Frame += speed;
        int n = frames.size();
        if (Frame >= n) Frame -= n;
        if (n > 0) sprite.setTextureRect(frames[int(Frame)]);
    }

    bool isEnd() {
        return Frame + speed >= frames.size();
    }
};

// Base Entity class for all game objects
class Entity {
public:
    float x, y, dx, dy, R, angle;
    bool life;
    std::string name;
    Animation anim;

    Entity() : x(0), y(0), dx(0), dy(0), R(0), angle(0), life(true) {}

    void settings(Animation& a, int X, int Y, float Angle = 0, int radius = 1) {
        anim = a;
        x = X;
        y = Y;
        angle = Angle;
        R = radius;
    }

    virtual void update() {}
    virtual void draw(RenderWindow& app) {
        anim.sprite.setPosition(x, y);
        anim.sprite.setRotation(angle + 90);
        app.draw(anim.sprite);
    }

    virtual ~Entity() {}
};

// Asteroid class derived from Entity class
class Asteroid : public Entity {
public:
    Text text;
    Font font;
    std::string word;

    Asteroid(const std::string& assignedWord) {
        name = "asteroid";
        word = assignedWord;

        if (!font.loadFromFile("C:/Users/HP15T-DY200/source/repos/ConsoleApplication2/ConsoleApplication2/Roboto/Roboto-Regular.ttf")) {
            std::cerr << "Error loading font\n";
        }

        text.setFont(font);
        text.setString(word);
        text.setCharacterSize(24);
        text.setFillColor(Color::White);
        text.setOrigin(text.getGlobalBounds().width / 2, text.getGlobalBounds().height / 2);

        dx = 0;
        dy = 0.75f;
    }

    void update() override {
        y += dy;
        if (y > WINDOW_HEIGHT) {
            life = false; // Asteroid is marked as dead
        }
        text.setPosition(x, y - R - 30);
    }

    void draw(RenderWindow& app) override {
        Entity::draw(app);
        app.draw(text);
    }
};

// Bullet class derived from Entity class
class Bullet : public Entity {
public:
    std::string targetWord;
    Asteroid* targetAsteroid;
    float speed;

    Bullet() {
        name = "bullet";
        speed = 6.0f;
        targetAsteroid = nullptr;
    }

    void setTarget(Asteroid* target) {
        targetAsteroid = target;
        targetWord = target->word;
    }

    void update() override {
        if (targetAsteroid) {
            float dx = targetAsteroid->x - x;
            float dy = targetAsteroid->y - y;
            float length = std::sqrt(dx * dx + dy * dy);
            if (length != 0) {
                dx /= length;
                dy /= length;
            }

            x += dx * speed;
            y += dy * speed;

            if (std::abs(x - targetAsteroid->x) < 5 && std::abs(y - targetAsteroid->y) < 5) {
                life = false;
                targetAsteroid->life = false;
            }
        }
        else {
            life = false;
        }
    }

    void draw(RenderWindow& app) override {
        anim.sprite.setRotation(0); // Ensuring bullet always faces up
        Entity::draw(app);
    }
};

// Player class derived from Entity class
class Player : public Entity {
public:
    bool thrust;
    int health;

    Player() {
        name = "player";
        angle = -90;
        health = 5;
    }

    void update() override {
        x = WINDOW_WIDTH / 2;
        y = WINDOW_HEIGHT - 50;
    }

    void loseHealth() {
        health--;
    }
};

// Function to check if two entities collide
bool isCollide(Entity* a, Entity* b) {
    return (b->x - a->x) * (b->x - a->x) +
        (b->y - a->y) * (b->y - a->y) <
        (a->R + b->R) * (a->R + b->R);
}

// Function to create an asteroid with a random word
Asteroid* createAsteroid(Animation& sRock, std::set<std::string>& activeWords) {
    std::string word;
    do {
        word = randomWords[rand() % randomWords.size()];
    } while (activeWords.find(word) != activeWords.end());

    activeWords.insert(word);
    Asteroid* a = new Asteroid(word);
    a->settings(sRock, rand() % WINDOW_WIDTH, rand() % (WINDOW_HEIGHT / 2), rand() % 360, 25);
    return a;
}

int main() {
    srand(time(0));  // Seed the random number generator

    RenderWindow app(VideoMode(WINDOW_WIDTH, WINDOW_HEIGHT), "Typefighters");
    app.setFramerateLimit(60);

    // Loading textures for various game elements
    Texture t1, t2, t3, t4, t5, t6, t7;
    t1.loadFromFile("images/spaceship.png");
    t2.loadFromFile("images/background.jpg");
    t3.loadFromFile("images/explosions/type_C.png"); // Asteroid explosion animation
    t4.loadFromFile("images/rock.png");
    t5.loadFromFile("images/fire_blue.png");
    t6.loadFromFile("images/rock_small.png");
    t7.loadFromFile("images/explosions/type_B.png"); // Ship explosion animation

    Sprite background(t2);

    // Initializing animations for various game elements
    Animation sExplosion(t3, 0, 0, 256, 256, 48, 0.5);
    Animation sRock(t4, 0, 0, 64, 64, 16, 0.2);
    Animation sRock_small(t6, 0, 0, 64, 64, 16, 0.2);
    Animation sBullet(t5, 0, 0, 32, 64, 16, 0.8);
    Animation sPlayer(t1, 40, 0, 40, 40, 1, 0);
    Animation sPlayer_go(t1, 40, 40, 40, 40, 1, 0);
    Animation sExplosion_ship(t7, 0, 0, 192, 192, 64, 0.5);

    std::list<Entity*> entities;         // List to store all entities in the game
    std::map<std::string, Asteroid*> wordToAsteroidMap; // Map to associate words with asteroids
    std::set<std::string> activeWords;   // Set to keep track of active words

    Player* p = new Player(); // Creating the player object
    p->settings(sPlayer, WINDOW_WIDTH / 2, WINDOW_HEIGHT - 50, -90, 20);
    entities.push_back(p);

    for (int i = 0; i < MAX_ASTEROIDS; i++) { // Creating initial set of asteroids
        Asteroid* a = createAsteroid(sRock, activeWords);
        entities.push_back(a);
        wordToAsteroidMap[a->word] = a;
    }

    std::string userInput; // String to store user input
    Font font; // Font for displaying text

    if (!font.loadFromFile("C:/Users/HP15T-DY200/source/repos/ConsoleApplication2/ConsoleApplication2/Roboto/Roboto-Regular.ttf")) {
        std::cerr << "Error loading font\n";
    }

    Text inputText("", font, 24); // Text for user input display
    inputText.setFillColor(Color::White);
    inputText.setPosition(10, WINDOW_HEIGHT - 50);

    Text healthText("", font, 24); // Text for displaying health
    healthText.setFillColor(Color::White);
    healthText.setPosition(10, 10);

    Text gameOverText("Game Over", font, 72); // Text for game over display
    gameOverText.setFillColor(Color::Red);
    gameOverText.setPosition(WINDOW_WIDTH / 2 - gameOverText.getGlobalBounds().width / 2, WINDOW_HEIGHT / 2 - gameOverText.getGlobalBounds().height / 2);

    bool gameOver = false; // Game over flag

    // Main game loop
    while (app.isOpen()) {
        Event event;
        while (app.pollEvent(event)) {
            if (event.type == Event::Closed)
                app.close();

            if (event.type == Event::TextEntered && !gameOver) {
                if (event.text.unicode == '\b') { // Handle backspace
                    if (!userInput.empty())
                        userInput.pop_back();
                }
                else if (event.text.unicode == '\r') { // Handle enter key
                    Asteroid* correctAsteroid = nullptr;
                    float minDistance = std::numeric_limits<float>::max();

                    for (auto& pair : wordToAsteroidMap) {
                        Asteroid* a = pair.second;
                        if (a->word == userInput) {
                            float dx = a->x - p->x;
                            float dy = a->y - p->y;
                            float distance = std::sqrt(dx * dx + dy * dy);

                            if (distance < minDistance) {
                                minDistance = distance;
                                correctAsteroid = a;
                            }
                        }
                    }

                    if (correctAsteroid) {
                        Bullet* b = new Bullet();
                        b->settings(sBullet, p->x, p->y, 0, 10);
                        b->setTarget(correctAsteroid);
                        entities.push_back(b);
                    }

                    userInput.clear();
                }
                else if (event.text.unicode < 128 && userInput.length() < MAX_INPUT_LENGTH) {
                    userInput += static_cast<char>(event.text.unicode);
                }
            }
        }

        inputText.setString(userInput);
        healthText.setString("Health: " + std::to_string(p->health));

        for (auto e : entities) {
            e->update();
        }

        for (auto e : entities) {
            if (e->name == "bullet" && !e->life) {
                entities.push_back(new Entity());
                e->settings(sExplosion, e->x, e->y, 0, 25);
            }
        }

        for (auto a : entities) {
            if (a->name == "asteroid" && !a->life) {
                entities.push_back(new Entity());
                a->settings(sExplosion, a->x, a->y, 0, 25);
            }
        }

        if (!p->life) {
            entities.push_back(new Entity());
            p->settings(sExplosion_ship, p->x, p->y, 0, 25);
            app.clear();
            app.draw(background);
            for (auto i : entities)
                i->draw(app);
            app.draw(inputText);
            app.display();
            sleep(milliseconds(2000));
            app.close();
        }

        entities.remove_if([&](Entity* e) {
            if (!e->life) {
                if (e->name == "asteroid") {
                    if (e->y >= WINDOW_HEIGHT) {
                        p->loseHealth();
                        if (p->health <= 0) {
                            p->life = false;
                            gameOver = true;
                        }
                    }
                    activeWords.erase(static_cast<Asteroid*>(e)->word);
                    Asteroid* a = createAsteroid(sRock, activeWords);
                    entities.push_back(a);
                    wordToAsteroidMap[a->word] = a;
                }
                delete e;
                return true;
            }
            return false;
            });

        app.clear();
        app.draw(background);

        for (auto i : entities)
            i->draw(app);

        app.draw(inputText);
        app.draw(healthText);

        if (gameOver) {
            app.draw(gameOverText);
        }

        app.display();
    }

    for (auto e : entities)
        delete e;

    return 0;
}
